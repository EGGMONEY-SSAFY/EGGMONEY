package com.ssafy.eggmoney.auth.dto.request;

public class WonRequest {
}
