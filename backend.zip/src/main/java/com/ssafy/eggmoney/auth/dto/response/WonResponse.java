package com.ssafy.eggmoney.auth.dto.response;

public class WonResponse {
}
