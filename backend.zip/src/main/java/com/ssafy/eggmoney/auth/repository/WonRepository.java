package com.ssafy.eggmoney.auth.repository;

public class WonRepository {
}
