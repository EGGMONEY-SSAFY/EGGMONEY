package com.ssafy.eggmoney.withdrawal.entity;

public enum WithdrawalStatus {
    PROGRESS,
    APPROVAL,
    REFUSAL;
}
