package com.ssafy.eggmoney.withdrawal.dto.request;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
public class GetWithdrawalRequestDto {
    Long userId;
}
