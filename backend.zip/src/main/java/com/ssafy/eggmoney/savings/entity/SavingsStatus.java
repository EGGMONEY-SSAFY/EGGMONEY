package com.ssafy.eggmoney.savings.entity;

public enum SavingsStatus {
    AVAILABLE, EXPIRED;
}
