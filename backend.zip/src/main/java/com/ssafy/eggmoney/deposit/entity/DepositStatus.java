package com.ssafy.eggmoney.deposit.entity;

public enum DepositStatus {
    AVAILABLE, EXPIRED;

}
