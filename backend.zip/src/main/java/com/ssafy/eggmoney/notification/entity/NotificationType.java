package com.ssafy.eggmoney.notification.entity;

public enum NotificationType {
    Loan;
}
