package com.ssafy.eggmoney.allowance.entity;

public enum AllowancePeriod {
    WEEK, MONTH;
}
