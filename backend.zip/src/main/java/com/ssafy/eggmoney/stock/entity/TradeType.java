package com.ssafy.eggmoney.stock.entity;

public enum TradeType {
    BUY,SELL;
}
