package com.ssafy.eggmoney.stock.dto.response;

import lombok.Getter;

import java.util.List;

@Getter
public class StockPricesResponse {
    private List<StockPriceResponse> output2;
}
